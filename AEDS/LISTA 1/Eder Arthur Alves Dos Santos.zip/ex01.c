#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2;

    printf("Digite um numero \n");

    scanf("%d", &n1);

    n2 = n1+1;

    printf("O numero digitado foi:\n%d", n2);
}
